import java.io.*;
import java.util.*;

public class JavaArrayList {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        String d = sc.nextLine();
        ArrayList> a = new ArrayList>(n);
        for (int i = 0; i < n; i++) {
            d = sc.nextLine();
            a.add(i, new ArrayList(Arrays.asList(d.split(" "))));
        }

        int q = sc.nextInt();
        for (int i = 0; i < q; i++) {
            int x = sc.nextInt();
            int y = sc.nextInt();
            if (x <= a.size() && y < a.get(x-1).size() && y >= 0) {
                System.out.println(a.get(x-1).get(y));
            } else {
                System.out.println("ERROR!");
            }
        }
    }
}

https://github.com/prasaddharani/SpringBoot
https://github.com/prasaddharani/SpringBoot
https://github.com/darbyluv2code/spring-and-hibernate-for-beginners/tree/master/02-spring-mvc-5
https://www.journaldev.com/2651/spring-mvc-exception-handling-controlleradvice-exceptionhandler-handlerexceptionresolver
https://www.kindsonthegenius.com/devops-ci-cd-pipeline-step-by-step-tutorial-springboot-github-heroku/
https://github.com/subbaraokari/jquery.git\
https://github.com/springframeworkguru/sfg-pet-clinic/tree/master/pet-clinic-data/src



HttpSession session = (HttpSession) request.getSession();
        User u = (User)session.getAttribute("user");
        cart.setUser(u);
        u.setCart(cart);
        Cart cd=null;
//        Cart c = cartDao.insert(cart);
//        User user1 = cartDao.update(u);
//         getSession().update(u);
         List<Cart> c=cartDao.list();
         int i=0;
         Cart cw = null;
         for(Cart cc:c){
             if(u.getPersonID()==cc.getId()){
                 cw = cartDao.updateCart(cc);
                 i=1;
                 return new ModelAndView("user-cart","c",cw);
             }
         }
     if (i==0){
          cd = cartDao.insert(cart);
     }
    
        return new ModelAndView("user-cart","c",cd);
    }
